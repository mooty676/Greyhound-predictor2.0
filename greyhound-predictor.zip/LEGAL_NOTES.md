LEGAL & COMPLIANCE NOTES (not legal advice)
- Do not rely on scraping as a long-term data source. Obtain Topaz / official API access.
- Selling a gambling-related product may trigger regulatory obligations depending on jurisdiction.
- Include Responsible Gambling messaging and a clear T&C that you're providing informational predictions only.
- Consult local counsel about advertising, licensing, consumer protection, and payment processing rules.
