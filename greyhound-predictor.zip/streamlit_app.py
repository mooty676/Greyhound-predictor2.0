import streamlit as st
import os
from src.scrapers import scrape_thedogs_racecard, scrape_racenet_racecard
from src.model_utils import load_model, predict
from src.topaz_client import TopazClient

st.set_page_config("Greyhound Predictor", layout="centered")
st.title("Greyhound Predictor — MVP")

mode = st.radio("Mode", ["User", "Admin"], index=0)

if mode == "Admin":
    st.header("Admin — Data & Model")
    st.markdown("Use this panel to (re)train model locally, manage data, or inspect logs.")
    st.info("Admin features are local-only in this MVP. In production, secure this behind auth.")
    uploaded = st.file_uploader("Upload historical CSV (for training)", type="csv")
    if uploaded:
        import pandas as pd
        df = pd.read_csv(uploaded)
        st.write("Preview:", df.head())
    if st.button("(Local) Train model from data/historical.csv"):
        st.info("Training started — check server logs.")
        from src.trainer import train_model
        try:
            train_model("data/historical.csv", out_model_path="models/xgb_model.pkl")
            st.success("Training complete. Model saved to models/xgb_model.pkl")
        except Exception as e:
            st.error(f"Training failed: {e}")
    st.stop()

# User mode
source = st.selectbox("Race source", ["TheDogs (URL)", "Racenet (URL)", "Topaz (API)", "Upload CSV"])
df = None

if source == "Upload CSV":
    up = st.file_uploader("Upload racecard CSV (columns: trap,name,last_runs)", type="csv")
    if up:
        import pandas as pd
        df = pd.read_csv(up)
elif source in ("TheDogs (URL)", "Racenet (URL)"):
    url = st.text_input("Paste race URL from TheDogs or Racenet")
    if st.button("Fetch racecard") and url:
        try:
            if "thedogs" in url:
                df = scrape_thedogs_racecard(url)
            elif "racenet" in url:
                df = scrape_racenet_racecard(url)
            else:
                st.error("Unsupported URL. Use TheDogs or Racenet.")
        except Exception as e:
            st.error(f"Failed to fetch: {e}")
elif source == "Topaz (API)":
    st.info("Topaz integration uses environment variable TOPAZ_API_KEY and is optional.")
    meet = st.text_input("Meeting ID or track (example: 'WENTWORTH' or meeting_id)")
    race_no = st.text_input("Race number (e.g. 5)")
    if st.button("Fetch from Topaz") and os.getenv("TOPAZ_API_KEY"):
        client = TopazClient(os.getenv("TOPAZ_API_KEY"))
        try:
            df = client.get_racecard(meet, race_no)
        except Exception as e:
            st.error(f"Topaz fetch failed: {e}")
    elif st.button("Fetch from Topaz"):
        st.error("TOPAZ_API_KEY not set in environment.")

if df is None:
    st.info("Provide a race source and fetch a race to get predictions.")
else:
    st.write("Runners found:", df[['trap','name']])
    model = None
    try:
        model = load_model("models/xgb_model.pkl")
    except Exception:
        st.warning("No trained model found — using heuristic fallback.")
    preds = predict(df, model)
    st.dataframe(preds[['trap','name','win_prob']])
    top = preds.iloc[0]
    st.success(f"Predicted winner: {top['name']} (trap {top['trap']}) — prob {top['win_prob']:.2f}")
