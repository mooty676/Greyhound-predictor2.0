# Greyhound Predictor — MVP (Deliverable)

This repository is a **production-ready MVP** for a greyhound race prediction app (Streamlit).
It includes scrapers (The Dogs / Racenet), a feature pipeline, a training script, a Streamlit UI,
and Docker + deployment helpers.

**Important:** This repo *does not* include paid/partner API keys (Topaz) or payment credentials.
For production reliability use official APIs (Topaz / GRV) and provide keys via environment variables.

## Quick start (local)
```bash
# Create venv and install
python -m venv venv
source venv/bin/activate    # mac/linux
pip install -r requirements.txt

# (Optional) Train a model using historical data
# python -m src.trainer --data data/historical.csv --out models/xgb_model.pkl

# Run Streamlit
streamlit run streamlit_app.py
```

## Deployment
Options included:
- Dockerfile for container builds
- `deploy/` contains sample Kubernetes manifests and a basic docker-compose

For Streamlit Cloud: push to GitHub and connect the repo; set `streamlit_app.py` as the entrypoint.

## What you must supply
- TOPAZ_API_KEY (recommended) or other race data API keys
- Optional bookmaker odds API keys
- Stripe keys if taking payments

See `LEGAL_NOTES.md` for compliance checklist and responsible-gambling wording.
