import joblib
from src.feature_engineering import featurize
import pandas as pd

def load_model(path='models/xgb_model.pkl'):
    return joblib.load(path)

def predict(df, model):
    X = featurize(df)
    try:
        probs = model.predict_proba(X)[:,1]
    except Exception:
        # fallback heuristic
        probs = (X['recent_wins']*0.5 + (10 - X['recent_avg_finish'])*0.1 + (8 - X['trap'])*0.05).fillna(0)
        probs = (probs - probs.min())/(probs.max()-probs.min()+1e-9)
    df = df.copy()
    df['win_prob'] = probs
    return df.sort_values('win_prob', ascending=False).reset_index(drop=True)
