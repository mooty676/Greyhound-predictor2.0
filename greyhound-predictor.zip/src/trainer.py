import argparse
import pandas as pd
import joblib
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss
from src.feature_engineering import featurize

def train_model(historical_csv_path, out_model_path='models/xgb_model.pkl'):
    df = pd.read_csv(historical_csv_path)
    if 'finish_pos' not in df.columns:
        raise ValueError('historical CSV must contain finish_pos column per dog')
    df['label'] = (df['finish_pos'] == 1).astype(int)
    X = featurize(df)
    y = df['label']
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    model = XGBClassifier(use_label_encoder=False, eval_metric='logloss', n_estimators=200, max_depth=4)
    model.fit(X_train, y_train, early_stopping_rounds=20, eval_set=[(X_val,y_val)], verbose=False)
    preds = model.predict_proba(X_val)[:,1]
    print('Logloss:', log_loss(y_val, preds))
    joblib.dump(model, out_model_path)
    print('Saved model to', out_model_path)
    return model

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--data', dest='data', required=True)
    p.add_argument('--out', dest='out', default='models/xgb_model.pkl')
    args = p.parse_args()
    train_model(args.data, args.out)
