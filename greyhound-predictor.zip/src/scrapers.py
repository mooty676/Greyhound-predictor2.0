import requests
from bs4 import BeautifulSoup
import pandas as pd
import re
HEADERS = {"User-Agent":"Mozilla/5.0 (compatible; GreyhoundPredictor/1.0)"}

def scrape_thedogs_racecard(url):
    """Simple TheDogs racecard scraper. May need selector updates over time."""
    r = requests.get(url, headers=HEADERS, timeout=15)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'lxml')
    runners = []
    # Attempt several selector patterns
    nodes = soup.select('.race-card__runner, .racecard__runner, .runner-item') or soup.select('.runner')
    if not nodes:
        # fallback: look for rows in a table
        nodes = soup.select('table tr')[:16]
    for node in nodes:
        try:
            name_node = node.select_one('.runner__name, .name, .runnerName') or node.select_one('td.name')
            name = name_node.get_text(strip=True) if name_node else node.get_text(strip=True)[:30]
            trap_node = node.select_one('.runner__trap, .trap, .box') or node.select_one('td.trap')
            trap = re.search(r"\d+", trap_node.get_text()) .group(0) if trap_node else ''
            form_node = node.select_one('.runner__form, .form, .last-runs') or node.select_one('td.form')
            last_runs = form_node.get_text(strip=True) if form_node else ''
            runners.append({'trap': trap, 'name': name, 'last_runs': last_runs})
        except Exception:
            continue
    return pd.DataFrame(runners)

def scrape_racenet_racecard(url):
    r = requests.get(url, headers=HEADERS, timeout=15)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'lxml')
    runners = []
    nodes = soup.select('.race-runner, .formRow, .field') or soup.select('table tr')[:16]
    for node in nodes:
        try:
            name_node = node.select_one('.runnerName, .name') or node.select_one('td.name')
            name = name_node.get_text(strip=True) if name_node else node.get_text(strip=True)[:30]
            trap_node = node.select_one('.trap, .box') or node.select_one('td.trap')
            trap = re.search(r"\d+", trap_node.get_text()).group(0) if trap_node else ''
            form_node = node.select_one('.recentForm, .form') or node.select_one('td.form')
            last_runs = form_node.get_text(strip=True) if form_node else ''
            runners.append({'trap': trap, 'name': name, 'last_runs': last_runs})
        except Exception:
            continue
    return pd.DataFrame(runners)
