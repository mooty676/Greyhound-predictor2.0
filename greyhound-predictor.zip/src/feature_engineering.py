import pandas as pd
import numpy as np
import re

def parse_form_string(form_str):
    nums = re.findall(r"\d+", str(form_str))
    nums = [int(n) for n in nums][:6]
    return nums

def featurize(df):
    X = pd.DataFrame()
    X['trap'] = pd.to_numeric(df.get('trap', 0), errors='coerce').fillna(0).astype(int)
    X['name_len'] = df.get('name','').str.len().fillna(0)
    wins = []
    avg_finish = []
    runs = []
    for s in df.get('last_runs', ['']*len(df)):
        nums = parse_form_string(s)
        runs.append(len(nums))
        wins.append(sum(1 for n in nums if n==1))
        avg_finish.append(float(np.mean(nums)) if nums else 99.0)
    X['recent_runs'] = runs
    X['recent_wins'] = wins
    X['recent_avg_finish'] = avg_finish
    return X
